

// eslint-disable-next-line max-len
const employers = ['АртеМ', 'максим', 'Владимир', 'сергей', 'НикиТа', 'евГений', ' Дарья', ' ', 'виктория ', 'ЕкаТерина', '', ' Андрей ', 'КИРИЛЛ'];
const nameCourse = 'Базовый React';
for (let i = 0; i < employers.length; i++) {
	if (employers[i].length > 0 && employers[i].trim() !== '') {
		employers[i] = employers[i].toLowerCase().trim();
		employers[i] = employers[i][0].toUpperCase() + employers[i].slice(1);
	}
}
const [...command]  = employers;
// console.log(...command);
const data = {
	cash: [3, 8, 3],
	react: ['JSX', 'components', 'props', 'state', 'hooks'],
	add: ['styled-components', 'firebase']
};


class makeBusiness {
	constructor(director, teacher, course, gang) {
		this.director = director;
		this.teacher = teacher;
		this.course = course;
		this.gang = gang;
	}
	calcCash(own) {
		own = own || 0;
		// eslint-disable-next-line prefer-rest-params
		const everyCash = Array.prototype.slice.call(arguments);
		let total = own;
		for (let i = 0; i < everyCash.length; i++) {
			total += +everyCash[1][i];
		}
		return total;
	}
	showmakeBusiness(lesson) {
		const sumTech = data.react.concat(data.add, 'и другие');
		console.log(`Стартуем новый курс: ${this.course}.
Владелец: ${this.director}, преподаватель: ${this.teacher}.
Всего уроков: ${lesson} .
Команда Академии: ${this.gang}

Первое что изучим будет ${data.react[0]}. Он очень похож на HTML! 

Технологии которые мы изучим: ${sumTech}`);
	}

}
const makeBusinessNew = new makeBusiness('Артем', 'Максим', nameCourse, command);
const lesson = makeBusinessNew.calcCash(null, data.cash);
makeBusinessNew.showmakeBusiness(lesson);


